// Frank Poth 03/09/2018

/* The Game class has been updated with a new Player class and given a new world
object that controls the virtual game world. Players, NPCs, world dimensions, collision
maps, and everything to do with the game world are stored in the world object. */

const Game = function() {

  this.world = {

    background_color:"rgba(166,197,241,0.3)",

    friction:0.9,
    gravity:4,

    player:new Game.Player(),
    object:new Game.Object(),

    height:72,
    width:128,

    collideObject:function(object) {

      if (object.x < 0) { object.x = 0; object.velocity_x = 0; }
      else if (object.x + object.width > this.width) { object.x = this.width - object.width; object.velocity_x = 0; }
      if (object.y < 0) { object.y = 0; object.velocity_y = 0; }
      else if (object.y + object.height > this.height) { object.jumping = false; object.y = this.height - object.height; object.velocity_y = 0; }

    },

    distance: function (x1, y1, x2, y2) {

        var dx = x1 - x2;
        var dy = y1 - y2;

        return Math.sqrt(dx * dx + dy * dy);

    },

    collideWall:function(player1, object2) {

      if (distance(object1.x, object1.y, object2.x, object2.y) < 10) { object1.velocity_x = 0; }
      // if (object.x < 0) { object.x = 0; object.velocity_x = 0; }
      // else if (object.x + object.width > this.width) { object.x = this.width - object.width; object.velocity_x = 0; }
      // if (object.y < 0) { object.y = 0; object.velocity_y = 0; }
      // else if (object.y + object.height > this.height) { object.jumping = false; object.y = this.height - object.height; object.velocity_y = 0; }

    },


    update:function() {

      this.player.velocity_y += this.gravity;
      this.player.update();

      this.player.velocity_x *= this.friction;
      this.player.velocity_y *= this.friction;

      this.collideObject(this.player);
      // this.collideObject(this.player, this.object);

    }

  };

  this.update = function() {

    this.world.update();

  };

};

Game.prototype = { constructor : Game };

Game.Player = function(x, y) {

  this.color      = "#" + Math.floor((Math.random() * 16777216) / 2).toString(16);
  this.height     = 16;
  this.jumping    = true;
  this.crouching  = true;
  this.velocity_x = 0;
  this.velocity_y = 0;
  this.width      = 8;
  this.x          = 100;
  this.y          = 50;

};

Game.Player.prototype = {

  constructor : Game.Player,

  jump:function() {

    if (!this.jumping) {

      // this.color = "#" + Math.floor(Math.random() * 16777216).toString(16);// Change to random color
      /* toString(16) will not add a leading 0 to a hex value, so this: #0fffff, for example,
      isn't valid. toString would cut off the first 0. The code below inserts it. */
      // if (this.color.length != 7) {
      //
      //   this.color = this.color.slice(0, 1) + "0" + this.color.slice(1, 6);
      //
      // }

      this.jumping     = true;
      this.velocity_y -= 20;

    }

  },

  crouch:function() {
      this.crouching = true;
      this.height = 8;
      // this.velocity_y -= 20;
  },

  uncrouch:function() {
      this.crouching = true;
      this.height = 16;
      // this.velocity_y -= 20;
  },

  moveLeft:function()  { this.velocity_x -= 0.5; },
  moveRight:function() { this.velocity_x += 0.5; },

  update:function() {

    this.x += this.velocity_x;
    this.y += this.velocity_y;
    // this.height = this.height;


  }

};

Game.Object = function(x, y) {

  this.color      = "#330033";
  this.height     = 16;
  this.velocity_x = 0;
  this.velocity_y = 0;
  this.width      = 16;
  this.x          = 50;
  this.y          = 48;

};
